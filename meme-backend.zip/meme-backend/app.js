const express = require('express');
const http = require('http');
const socketIo = require('socket.io');

// Inicializa PocketBase de forma asíncrona
let pb;

async function initializePocketBase() {
    if (!pb) {
        const PocketBase = (await import('pocketbase')).default;
        pb = new PocketBase('http://127.0.0.1:8090');
        //console.log("connectado a pocketbase",pb);
    }
}

const app = express();
//app.use(cors()); // Usa CORS con opciones predeterminadas
//const server = http.createServer(app);
//const io = socketIo(server, {
//    cors: {
//      origin: "*", // Aquí puedes especificar los dominios permitidos o usar '*' para permitir todos
//      methods: ["GET", "POST"], // Métodos HTTP permitidos
//      // Puedes agregar más opciones de CORS si es necesario
//    },
//  });
//
//app.use(express.static('public'));

//app.get('/', (req, res) => {
//    res.sendFile(path.join(__dirname, 'public', 'index.html'));
//});

const server = http.createServer(app);
const io = socketIo(server, {
    cors: {
      origin: "*", // Permite todos los orígenes
      methods: ["GET", "POST"], // Métodos HTTP permitidos
      // Puedes agregar más opciones de CORS si es necesario
    },
});

// Realiza la inicialización de PocketBase antes de configurar el resto del servidor
initializePocketBase().then(() => {
    console.log('PocketBase inicializado');
    io.on('connection', (socket) => {
        console.log('Nuevo cliente conectado');
        
        socket.on('joinRoom', async (userId) => {
            console.log('joinRoom event received with ID:', userId);
    
            try {
                let room = await findOrCreateRoom(userId);
                socket.join(room.id);
                console.log(`Usuario ${userId} se ha unido a la habitación ${room.id}`);
                io.in(room.id).emit('roomData', room);
                socket.emit('joinedRoom', room.id);
            } catch (error) {
                console.log('Error al unir o crear sala:', error);
            }
        });
    
        socket.on('disconnect', () => {
            console.log('Cliente desconectado');
        });
    });
    
    
    async function findOrCreateRoom(userId) {
        try {
            let rooms = await pb.records.getList('rooms', 1, 50, { filter: 'state != "full"' });
            
            // Buscar salas disponibles
            for (let room of rooms.items) {
                if (!room.player2) {
                    // Si hay una sala esperando y no tiene player2, actualízala y únete a esa.
                    let updatedRoom = await pb.records.update('rooms', room.id, {
                        player2: userId,
                        state: 'full', // Actualizar el estado a 'full' porque ahora tiene dos jugadores.
                        currentTurn: room.player1 // Suponiendo que el jugador1 comienza.
                    });
                    return updatedRoom;
                }
            }
    
            // Si no hay salas disponibles, crear una nueva sala
            let newRoomData = {
                player1: userId, // El ID del usuario que crea la sala
                name: "1vs1", // Un nombre único para la sala
                state: 'waiting', // Estado inicial 'waiting' para indicar que está esperando a otro jugador.
                gamestate: {}, // Estado inicial del juego, por ejemplo, podría ser un objeto vacío.
                currentTurn: userId, // El usuario que crea la sala tiene el primer turno.
                score_player_1: 0, // Puntuación inicial del jugador 1.
                score_player_2: 0, // Puntuación inicial del jugador 2.
                gameData: {}, // Datos adicionales del juego, podría ser un objeto vacío.
                // Asegúrate de que todos los campos requeridos por tu esquema estén aquí.
            };
    
            let createdRoom = await pb.records.create('rooms', newRoomData);
            return createdRoom;
        } catch (error) {
            console.error('Error al buscar o crear sala:', error);
            throw error;
        }
    }
    
    server.listen(3000, () => {
        console.log('Servidor escuchando en http://localhost:3000');
    });
    
}).catch(console.error);

